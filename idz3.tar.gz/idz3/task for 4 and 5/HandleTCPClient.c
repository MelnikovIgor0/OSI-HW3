#include <stdio.h>      /* for printf() and fprintf() */
#include <sys/socket.h> /* for recv() and send() */
#include <unistd.h>     /* for close() */
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>

#define RCVBUFSIZE 32   /* Size of receive buffer */

void DieWithError(char *errorMessage);  /* Error handling function */

void HandleTCPClient(int clntSocket, int cashierNum)
{
    char echoBuffer[] = "lolkeklolkek";
    int clientNum = 100000000 * cashierNum + 1;
    snprintf(echoBuffer, sizeof(echoBuffer), "%d", clientNum);
    int recvMsgSize = strlen(echoBuffer);

    /* Receive message from client */
    if ((recvMsgSize = recv(clntSocket, echoBuffer, RCVBUFSIZE, 0)) < 0)
        DieWithError("recv() failed");
    snprintf(echoBuffer, sizeof(echoBuffer), "%d", clientNum);
    recvMsgSize = strlen(echoBuffer);

    /* Send received string and receive again until end of transmission */
    while (recvMsgSize > 0)      /* zero indicates end of transmission */
    {
        /* Echo message back to client */
        snprintf(echoBuffer, sizeof(echoBuffer), "%d", clientNum);
        recvMsgSize = strlen(echoBuffer);
        printf("created buyer for cashier %d, local buyer's id: %d\n", clientNum / 100000000, clientNum % 100000000);
        if (send(clntSocket, echoBuffer, recvMsgSize, 0) != recvMsgSize)
            DieWithError("send() failed");

        /* See if there is more data to receive */
        recv(clntSocket, echoBuffer, RCVBUFSIZE, 0);
        ++clientNum;
    }
    
    close(clntSocket);    /* Close client socket */
}
