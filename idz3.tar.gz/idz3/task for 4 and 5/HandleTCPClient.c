#include <stdio.h>
#include <sys/socket.h>
#include <unistd.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>

#define RCVBUFSIZE 32

void DieWithError(char *errorMessage);

void HandleTCPClient(int clntSocket, int cashierNum)
{
    char echoBuffer[] = "lolkeklolkek";
    int clientNum = 100000000 * cashierNum + 1;
    snprintf(echoBuffer, sizeof(echoBuffer), "%d", clientNum);
    int recvMsgSize = strlen(echoBuffer);

    if ((recvMsgSize = recv(clntSocket, echoBuffer, RCVBUFSIZE, 0)) < 0)
        DieWithError("recv() failed");
    snprintf(echoBuffer, sizeof(echoBuffer), "%d", clientNum);
    recvMsgSize = strlen(echoBuffer);

    while (recvMsgSize > 0)
    {
        snprintf(echoBuffer, sizeof(echoBuffer), "%d", clientNum);
        recvMsgSize = strlen(echoBuffer);
        printf("created buyer for cashier %d, local buyer's id: %d\n", clientNum / 100000000, clientNum % 100000000);
        if (send(clntSocket, echoBuffer, recvMsgSize, 0) != recvMsgSize)
            DieWithError("send() failed");

        recv(clntSocket, echoBuffer, RCVBUFSIZE, 0);
        ++clientNum;
    }
    
    close(clntSocket);
}
