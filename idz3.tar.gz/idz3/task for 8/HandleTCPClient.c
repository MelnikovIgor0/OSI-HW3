#include <stdio.h>
#include <sys/socket.h>
#include <unistd.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>

#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

#define RCVBUFSIZE 128

void DieWithError(char *errorMessage);

void HandleTCPClient(int clntSocket, int cashierNum)
{
    char echoBuffer[RCVBUFSIZE];
    int clientNum = 100000000 * cashierNum + 1;
    int recvMsgSize;

    if ((recvMsgSize = recv(clntSocket, echoBuffer, RCVBUFSIZE, 0)) < 0)
        DieWithError("recv() failed");
    FILE *fptr = NULL;
    char fileBuffer[RCVBUFSIZE];
    if (recvMsgSize > 0 && echoBuffer[0] == '1') {
        snprintf(echoBuffer, sizeof(echoBuffer), "%d", clientNum);
        recvMsgSize = strlen(echoBuffer);
        int isFirst = 1;

        while (recvMsgSize > 0)
        {
            /*if (!isFirst) {
                fptr = fopen("buffer.txt", "w");
                fprintf(fptr, "buyer %d served by cashier %d\n", clientNum % 100000000 - 1, clientNum / 100000000);
                fclose(fptr);
            }*/
            snprintf(echoBuffer, sizeof(echoBuffer), "%d", clientNum);
            recvMsgSize = strlen(echoBuffer);
            printf("created buyer for cashier %d, local buyer's id: %d\n",
                   clientNum / 100000000, clientNum % 100000000);

            fptr = fopen("buffer.txt", "w");
            fprintf(fptr, "created buyer %d for cashier %d\n", clientNum % 100000000, clientNum / 100000000);
            fclose(fptr);

            if (send(clntSocket, echoBuffer, recvMsgSize, 0) != recvMsgSize)
                DieWithError("send() failed");

            recv(clntSocket, echoBuffer, RCVBUFSIZE, 0);

            fptr = fopen("buffer.txt", "w");
            fprintf(fptr, "buyer %d served by cashier %d\n", clientNum % 100000000, clientNum / 100000000);
            fclose(fptr);

            ++clientNum;
            isFirst = 0;
            sleep(1);
        }
    } else if (recvMsgSize > 0 && echoBuffer[0] == '2') {
        while (1) {
            fptr = fopen("buffer.txt", "r");
            while ((fgets(fileBuffer, RCVBUFSIZE, fptr)) != NULL) {
                printf("read data from fileBuffer: %s\n", fileBuffer);
                send(clntSocket, fileBuffer, strlen(fileBuffer), 0);
            }
            recvMsgSize = strlen(fileBuffer);
            fclose(fptr);
            fclose(fopen("buffer.txt", "w"));
            for (int i = 0; i < 100000000; ++i) { }
        }
    }
    
    close(clntSocket);
}
